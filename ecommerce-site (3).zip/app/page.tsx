import ProductCatalog from "@/components/product-catalog"

export default function Home() {
  return (
    <main className="min-h-screen">
      <ProductCatalog />
    </main>
  )
}

