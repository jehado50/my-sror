"use client"

import { useState } from "react"
import { ChevronDown } from "lucide-react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

// Sample product data
const products = [
  {
    id: 1,
    name: "Wireless Headphones",
    description: "Premium noise-cancelling wireless headphones",
    price: 199.99,
    type: "electronics",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 2,
    name: "Cotton T-Shirt",
    description: "Comfortable 100% cotton t-shirt",
    price: 24.99,
    type: "clothing",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 3,
    name: "Ceramic Coffee Mug",
    description: "Handcrafted ceramic coffee mug",
    price: 14.99,
    type: "homeware",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 4,
    name: "Smartphone",
    description: "Latest model smartphone with advanced features",
    price: 899.99,
    type: "electronics",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 5,
    name: "Running Shoes",
    description: "Lightweight running shoes with cushioned soles",
    price: 129.99,
    type: "clothing",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    id: 6,
    name: "Scented Candle",
    description: "Long-lasting scented candle in decorative jar",
    price: 19.99,
    type: "homeware",
    image: "/placeholder.svg?height=200&width=200",
  },
]

// Get unique product types
const productTypes = ["all", ...new Set(products.map((product) => product.type))]

export default function ProductList() {
  const [selectedType, setSelectedType] = useState("all")

  // Filter products based on selected type
  const filteredProducts =
    selectedType === "all" ? products : products.filter((product) => product.type === selectedType)

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <p className="text-muted-foreground">
          Showing {filteredProducts.length} of {products.length} products
        </p>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="flex items-center gap-2">
              Filter by: {selectedType.charAt(0).toUpperCase() + selectedType.slice(1)}
              <ChevronDown className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-[200px]">
            <DropdownMenuRadioGroup value={selectedType} onValueChange={setSelectedType}>
              {productTypes.map((type) => (
                <DropdownMenuRadioItem key={type} value={type} className="capitalize">
                  {type}
                </DropdownMenuRadioItem>
              ))}
            </DropdownMenuRadioGroup>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProducts.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  )
}

function ProductCard({ product }) {
  return (
    <Card className="overflow-hidden h-full flex flex-col">
      <div className="relative aspect-square">
        <Image src={product.image || "/placeholder.svg"} alt={product.name} fill className="object-cover" />
      </div>
      <CardContent className="pt-6 flex-grow">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-semibold text-lg">{product.name}</h3>
          <Badge variant="outline" className="capitalize">
            {product.type}
          </Badge>
        </div>
        <p className="text-muted-foreground text-sm">{product.description}</p>
      </CardContent>
      <CardFooter className="flex justify-between items-center pt-2 pb-6">
        <span className="font-semibold">${product.price.toFixed(2)}</span>
        <Button size="sm">Add to Cart</Button>
      </CardFooter>
    </Card>
  )
}

