"use client"

import { useState } from "react"
import Link from "next/link"
import { ShoppingCart, Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Badge } from "@/components/ui/badge"

export default function Header({ cartItemCount = 0 }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2 md:gap-6">
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
          <Link href="/" className="text-xl font-bold">
            ShopEase
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium hover:underline underline-offset-4">
              Home
            </Link>
            <Link href="#products" className="text-sm font-medium hover:underline underline-offset-4">
              Products
            </Link>
            <Link href="#categories" className="text-sm font-medium hover:underline underline-offset-4">
              Categories
            </Link>
            <Link href="#about" className="text-sm font-medium hover:underline underline-offset-4">
              About
            </Link>
          </nav>
        </div>

        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="relative">
              <ShoppingCart className="h-5 w-5" />
              {cartItemCount > 0 && (
                <Badge className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 text-xs">
                  {cartItemCount}
                </Badge>
              )}
            </Button>
          </SheetTrigger>
          <SheetContent>
            <div className="flex flex-col h-full">
              <div className="py-4 border-b">
                <h2 className="text-lg font-semibold">Your Cart</h2>
                <p className="text-sm text-muted-foreground">
                  {cartItemCount} {cartItemCount === 1 ? "item" : "items"} in your cart
                </p>
              </div>
              {cartItemCount === 0 ? (
                <div className="flex-1 flex items-center justify-center">
                  <div className="text-center">
                    <ShoppingCart className="h-12 w-12 mx-auto text-muted-foreground" />
                    <p className="mt-4 text-muted-foreground">Your cart is empty</p>
                    <Button className="mt-4" variant="outline">
                      Start Shopping
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="flex-1">{/* Cart items would go here */}</div>
              )}
              <div className="border-t py-4 mt-auto">
                <div className="flex justify-between mb-4">
                  <span>Subtotal</span>
                  <span className="font-semibold">$0.00</span>
                </div>
                <Button className="w-full">Checkout</Button>
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden border-t p-4 bg-background">
          <nav className="flex flex-col space-y-4">
            <Link href="/" className="text-sm font-medium" onClick={() => setIsMenuOpen(false)}>
              Home
            </Link>
            <Link href="#products" className="text-sm font-medium" onClick={() => setIsMenuOpen(false)}>
              Products
            </Link>
            <Link href="#categories" className="text-sm font-medium" onClick={() => setIsMenuOpen(false)}>
              Categories
            </Link>
            <Link href="#about" className="text-sm font-medium" onClick={() => setIsMenuOpen(false)}>
              About
            </Link>
          </nav>
        </div>
      )}
    </header>
  )
}

