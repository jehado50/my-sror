"use client"

import { Badge } from "@/components/ui/badge"

import { useState } from "react"
import { Filter, SlidersHorizontal, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Separator } from "@/components/ui/separator"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Header from "@/components/header"
import ProductGrid from "@/components/product-grid"
import { products, categories } from "@/data/products"

export default function ProductCatalog() {
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [priceRange, setPriceRange] = useState<string>("all")
  const [sortBy, setSortBy] = useState<string>("featured")
  const [cartItems, setCartItems] = useState<number>(0)

  // Filter products based on selected categories and price range
  const filteredProducts = products.filter((product) => {
    // Category filter
    if (selectedCategories.length > 0 && !selectedCategories.includes(product.category)) {
      return false
    }

    // Price range filter
    if (priceRange === "under50" && product.price >= 50) return false
    if (priceRange === "50to100" && (product.price < 50 || product.price > 100)) return false
    if (priceRange === "100to200" && (product.price < 100 || product.price > 200)) return false
    if (priceRange === "over200" && product.price <= 200) return false

    return true
  })

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortBy === "priceLowToHigh") return a.price - b.price
    if (sortBy === "priceHighToLow") return b.price - a.price
    if (sortBy === "newest") return new Date(b.date).getTime() - new Date(a.date).getTime()
    // Default: featured
    return 0
  })

  const handleCategoryChange = (category: string) => {
    setSelectedCategories((prev) =>
      prev.includes(category) ? prev.filter((c) => c !== category) : [...prev, category],
    )
  }

  const clearAllFilters = () => {
    setSelectedCategories([])
    setPriceRange("all")
  }

  const addToCart = () => {
    setCartItems((prev) => prev + 1)
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Header cartItemCount={cartItems} />

      <div className="container py-8">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Desktop Filters Sidebar */}
          <div className="hidden md:block w-64 shrink-0">
            <div className="sticky top-24">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold">Filters</h2>
                {(selectedCategories.length > 0 || priceRange !== "all") && (
                  <Button variant="ghost" size="sm" onClick={clearAllFilters}>
                    Clear all
                  </Button>
                )}
              </div>

              <div className="space-y-6">
                <div>
                  <h3 className="font-medium mb-3">Categories</h3>
                  <div className="space-y-2">
                    {categories.map((category) => (
                      <div key={category.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`category-${category.id}`}
                          checked={selectedCategories.includes(category.id)}
                          onCheckedChange={() => handleCategoryChange(category.id)}
                        />
                        <label
                          htmlFor={`category-${category.id}`}
                          className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {category.name}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                <div>
                  <h3 className="font-medium mb-3">Price Range</h3>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="price-all"
                        checked={priceRange === "all"}
                        onCheckedChange={() => setPriceRange("all")}
                      />
                      <label htmlFor="price-all" className="text-sm leading-none">
                        All prices
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="price-under50"
                        checked={priceRange === "under50"}
                        onCheckedChange={() => setPriceRange("under50")}
                      />
                      <label htmlFor="price-under50" className="text-sm leading-none">
                        Under $50
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="price-50to100"
                        checked={priceRange === "50to100"}
                        onCheckedChange={() => setPriceRange("50to100")}
                      />
                      <label htmlFor="price-50to100" className="text-sm leading-none">
                        $50 to $100
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="price-100to200"
                        checked={priceRange === "100to200"}
                        onCheckedChange={() => setPriceRange("100to200")}
                      />
                      <label htmlFor="price-100to200" className="text-sm leading-none">
                        $100 to $200
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="price-over200"
                        checked={priceRange === "over200"}
                        onCheckedChange={() => setPriceRange("over200")}
                      />
                      <label htmlFor="price-over200" className="text-sm leading-none">
                        Over $200
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Mobile Filter Button */}
          <div className="md:hidden">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" className="w-full flex items-center justify-center gap-2">
                  <Filter className="h-4 w-4" />
                  Filters
                  {(selectedCategories.length > 0 || priceRange !== "all") && (
                    <Badge variant="secondary" className="ml-2">
                      {selectedCategories.length + (priceRange !== "all" ? 1 : 0)}
                    </Badge>
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-full sm:max-w-md">
                <div className="flex flex-col h-full">
                  <div className="flex items-center justify-between py-4 border-b">
                    <h2 className="text-lg font-semibold">Filters</h2>
                    {(selectedCategories.length > 0 || priceRange !== "all") && (
                      <Button variant="ghost" size="sm" onClick={clearAllFilters}>
                        Clear all
                      </Button>
                    )}
                  </div>

                  <div className="flex-1 overflow-auto py-4">
                    <div className="space-y-6">
                      <div>
                        <h3 className="font-medium mb-3">Categories</h3>
                        <div className="space-y-2">
                          {categories.map((category) => (
                            <div key={category.id} className="flex items-center space-x-2">
                              <Checkbox
                                id={`mobile-category-${category.id}`}
                                checked={selectedCategories.includes(category.id)}
                                onCheckedChange={() => handleCategoryChange(category.id)}
                              />
                              <label
                                htmlFor={`mobile-category-${category.id}`}
                                className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                              >
                                {category.name}
                              </label>
                            </div>
                          ))}
                        </div>
                      </div>

                      <Separator />

                      <div>
                        <h3 className="font-medium mb-3">Price Range</h3>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="mobile-price-all"
                              checked={priceRange === "all"}
                              onCheckedChange={() => setPriceRange("all")}
                            />
                            <label htmlFor="mobile-price-all" className="text-sm leading-none">
                              All prices
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="mobile-price-under50"
                              checked={priceRange === "under50"}
                              onCheckedChange={() => setPriceRange("under50")}
                            />
                            <label htmlFor="mobile-price-under50" className="text-sm leading-none">
                              Under $50
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="mobile-price-50to100"
                              checked={priceRange === "50to100"}
                              onCheckedChange={() => setPriceRange("50to100")}
                            />
                            <label htmlFor="mobile-price-50to100" className="text-sm leading-none">
                              $50 to $100
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="mobile-price-100to200"
                              checked={priceRange === "100to200"}
                              onCheckedChange={() => setPriceRange("100to200")}
                            />
                            <label htmlFor="mobile-price-100to200" className="text-sm leading-none">
                              $100 to $200
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="mobile-price-over200"
                              checked={priceRange === "over200"}
                              onCheckedChange={() => setPriceRange("over200")}
                            />
                            <label htmlFor="mobile-price-over200" className="text-sm leading-none">
                              Over $200
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="border-t py-4 mt-auto">
                    <Button className="w-full">Apply Filters</Button>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Product Grid and Sorting */}
          <div className="flex-1">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
              <div>
                <h1 className="text-2xl font-bold">All Products</h1>
                <p className="text-muted-foreground">
                  Showing {sortedProducts.length} of {products.length} products
                </p>
              </div>

              <div className="flex items-center w-full sm:w-auto">
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-full sm:w-[180px]">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="featured">Featured</SelectItem>
                    <SelectItem value="newest">Newest</SelectItem>
                    <SelectItem value="priceLowToHigh">Price: Low to High</SelectItem>
                    <SelectItem value="priceHighToLow">Price: High to Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Active filters */}
            {(selectedCategories.length > 0 || priceRange !== "all") && (
              <div className="flex flex-wrap gap-2 mb-6">
                {selectedCategories.map((categoryId) => {
                  const category = categories.find((c) => c.id === categoryId)
                  return (
                    <Badge key={categoryId} variant="secondary" className="flex items-center gap-1">
                      {category?.name}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-4 w-4 p-0 hover:bg-transparent"
                        onClick={() => handleCategoryChange(categoryId)}
                      >
                        <X className="h-3 w-3" />
                        <span className="sr-only">Remove {category?.name} filter</span>
                      </Button>
                    </Badge>
                  )
                })}

                {priceRange !== "all" && (
                  <Badge variant="secondary" className="flex items-center gap-1">
                    {priceRange === "under50" && "Under $50"}
                    {priceRange === "50to100" && "$50 to $100"}
                    {priceRange === "100to200" && "$100 to $200"}
                    {priceRange === "over200" && "Over $200"}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-4 w-4 p-0 hover:bg-transparent"
                      onClick={() => setPriceRange("all")}
                    >
                      <X className="h-3 w-3" />
                      <span className="sr-only">Remove price filter</span>
                    </Button>
                  </Badge>
                )}
              </div>
            )}

            {/* Product grid */}
            <ProductGrid products={sortedProducts} onAddToCart={addToCart} />

            {/* Empty state */}
            {sortedProducts.length === 0 && (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <SlidersHorizontal className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold">No products found</h3>
                <p className="text-muted-foreground mt-2 mb-6">
                  Try adjusting your filters to find what you're looking for.
                </p>
                <Button onClick={clearAllFilters}>Clear all filters</Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

